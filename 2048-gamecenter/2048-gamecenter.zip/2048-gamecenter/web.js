/**
 * Module dependencies.
 */
var express = require('express');

var http = require('http');
var path = require('path');

var mongo = require('mongodb');


var app = express();
/*set up mongo*/
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://http://young-springs-5689.herokuapp.com/scores';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});



app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));


if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

/* renders html on the home page, inserts scores, names and timestamps
 * in a table
 */
app.get('/', function(req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
      col.find({}).sort({score:-1}).toArray(function(err, x){
         var index = "<!DOCTYPE HTML><html><head><title>2048 Game Center</title></head><body><h1> 2048 Game Center </h1><table><tr><th>USER</th><th>SCORE</th><th>TIMESTAMP</th></tr>";
        for(i = 0; i < x.length; i++){
            index += "<tr><td>" + x[i].username + "</td><td>" + x[i].score + "</td><td>"
            + x[i].created_at + "</td></tr>";
            console.log(x[i].score);
        }
        console.log(x.length);
        index += "</table></body></html>";
        res.send(index);
        });
      });
    });
});

/* sends information to the /scores.json based on a username query. If no query
 * exists then an empty array is displayed 
 */

app.get('/scores.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
      name = req.query.username;
      if(req.query.username){
      var d = col.find({username: name}).sort({score:-1}).toArray(function(err, x){
            if(err){
                res.send(500, 'Failed!');
            }
            else{
              res.send(x);
            }
      });
      }
      else {
            res.send([]);
           }
    });
  });
});
/* takes data from a POST and inserts into a mongodb named scores if
 * all fields are present.
 */
app.post('/submit.json', function (req, res){
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, collection){
      var score = Number(req.body.score);
      var name = req.body.username;
      var grid = req.body.grid;
      var date = new Date();
      var day = date.getDate();
      var month = date.getMonth() + 1;
      var year = date.getFullYear();
      var hours = (date.getHours() + 20)%24;
      var minutes = date.getMinutes();
      var seconds = date.getSeconds();
      var created_at = month + "/" + day + "/" + year + " " + hours + ":" + minutes + ":" + seconds;
      if(score && name && grid) {
      collection.insert({"score": score, "username": name, "created_at": created_at, "grid": grid}, function (err, r){});
      res.send(200);
      }
    });
  });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});